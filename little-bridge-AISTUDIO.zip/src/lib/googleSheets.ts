// Google Sheets — versión sin Firebase Auth.
// El envío real a la planilla se hace en App.tsx (fetch al Apps Script).
// Estas funciones se mantienen con la misma firma para no romper imports,
// pero son inofensivas (no abren popups ni piden login).

import { Submission } from "../submissions";

export const SPREADSHEET_ID = "1gvaanALVlw8FGN5KM3j4x4-c7Xa1WoypksMStbz47pQ";

// Ya no se usa login de Google: el Apps Script escribe con permisos de la dueña.
export const initAuth = (
  _onAuthSuccess?: (user: any, token: string) => void,
  onAuthFailure?: () => void
) => {
  if (onAuthFailure) onAuthFailure();
  return () => {};
};

export const googleSignIn = async (): Promise<{ user: any; accessToken: string } | null> => {
  // Sin login: devolvemos null. El envío no depende de esto.
  return null;
};

export const getAccessToken = async (): Promise<string | null> => null;

export const logout = async () => {};

// Se conserva por compatibilidad; ya no se llama en el flujo principal.
export async function appendSubmissionToGoogleSheets(
  _accessToken: string,
  _submission: Submission,
  _spreadsheetId: string = SPREADSHEET_ID
): Promise<{ success: boolean; error?: string }> {
  return { success: false, error: "Integración OAuth desactivada. El envío se hace vía Apps Script." };
}
